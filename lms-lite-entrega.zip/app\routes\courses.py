﻿from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from .. import db
from ..models import Curso, Leccion, EstadoCurso, Inscripcion, Progreso
from ..utils.authz import require_role

bp = Blueprint("courses", __name__)

@bp.get("/")
def list_public():
    cursos = Curso.query.filter_by(estado=EstadoCurso.PUBLICADO).all()
    return {"items": [{"id": c.id, "titulo": c.titulo, "docente_id": c.docente_id} for c in cursos]}

@bp.get("/<int:curso_id>")
def get_course(curso_id):
    c = Curso.query.get_or_404(curso_id)
    return {"id": c.id, "titulo": c.titulo, "descripcion": c.descripcion, "estado": c.estado.value, "docente_id": c.docente_id}

@bp.get("/<int:curso_id>/lessons")
def list_lessons(curso_id):
    les = Leccion.query.filter_by(curso_id=curso_id).order_by(Leccion.orden.asc()).all()
    return {"items": [{"id": l.id, "titulo": l.titulo, "orden": l.orden} for l in les]}

@bp.post("/")
@jwt_required()
@require_role("DOCENTE")
def create_course():
    user_id = int(get_jwt_identity())
    data = request.get_json() or {}
    c = Curso(titulo=data["titulo"], descripcion=data.get("descripcion", ""),
              estado=EstadoCurso(data.get("estado", "BORRADOR")),
              docente_id=user_id)
    db.session.add(c); db.session.commit()
    return {"id": c.id, "titulo": c.titulo}, 201

@bp.post("/<int:curso_id>/lessons")
@jwt_required()
@require_role("DOCENTE")
def add_lesson(curso_id):
    data = request.get_json() or {}
    le = Leccion(curso_id=curso_id, titulo=data["titulo"],
                 contenido=data.get("contenido", ""), video_url=data.get("video_url"),
                 orden=data.get("orden", 1))
    db.session.add(le); db.session.commit()
    return {"id": le.id, "titulo": le.titulo}, 201

@bp.post("/<int:curso_id>/publish")
@jwt_required()
@require_role("DOCENTE")
def publish_course(curso_id):
    curso = Curso.query.get_or_404(curso_id)
    curso.estado = EstadoCurso.PUBLICADO
    db.session.commit()
    return {"ok": True}

@bp.post("/<int:curso_id>/enroll")
@jwt_required()
def enroll(curso_id):
    user_id = int(get_jwt_identity())
    ins = Inscripcion(estudiante_id=user_id, curso_id=curso_id)
    db.session.add(ins); db.session.commit()
    pr = Progreso(estudiante_id=user_id, curso_id=curso_id, porcentaje=0.0)
    db.session.add(pr); db.session.commit()
    return {"ok": True, "inscripcion_id": ins.id}
