﻿from flask import Blueprint, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from .. import db
from ..models import Quiz, Pregunta, Opcion, IntentoQuiz

bp = Blueprint("quizzes", __name__)

@bp.get("/<int:quiz_id>")
def get_quiz(quiz_id):
    q = Quiz.query.get_or_404(quiz_id)
    total_p = Pregunta.query.filter_by(quiz_id=q.id).count()
    return {"id": q.id, "curso_id": q.curso_id, "titulo": q.titulo,
            "tiempo_limite_min": q.tiempo_limite_min, "intentos_max": q.intentos_max,
            "preguntas": total_p}

@bp.get("/<int:quiz_id>/questions")
@jwt_required()
def list_questions(quiz_id):
    preguntas = Pregunta.query.filter_by(quiz_id=quiz_id).all()
    payload = []
    for p in preguntas:
        opciones = Opcion.query.filter_by(pregunta_id=p.id).all()
        payload.append({
            "id": p.id,
            "enunciado": p.enunciado,
            "opciones": [{"id": o.id, "texto": o.texto, "correcta": o.correcta} for o in opciones]
        })
    return payload

@bp.post("/")
@jwt_required()
def create_quiz():
    data = request.get_json() or {}
    q = Quiz(curso_id=data["curso_id"], titulo=data["titulo"],
             tiempo_limite_min=data.get("tiempo_limite_min", 20),
             intentos_max=data.get("intentos_max", 2))
    db.session.add(q); db.session.commit()
    return {"id": q.id, "titulo": q.titulo}, 201

@bp.post("/<int:quiz_id>/questions")
@jwt_required()
def add_question(quiz_id):
    data = request.get_json() or {}
    p = Pregunta(quiz_id=quiz_id, enunciado=data["enunciado"], tipo=data.get("tipo", "MULTIPLE"))
    db.session.add(p); db.session.flush()
    opts = []
    for opt in data.get("opciones", []):
        obj = Opcion(pregunta_id=p.id, texto=opt["texto"], correcta=opt.get("correcta", False))
        db.session.add(obj); db.session.flush()
        opts.append({"id": obj.id, "texto": obj.texto, "correcta": obj.correcta})
    db.session.commit()
    return {"id": p.id, "enunciado": p.enunciado, "opciones": opts}, 201

@bp.post("/<int:quiz_id>/attempts")
@jwt_required()
def start_attempt(quiz_id):
    user_id = int(get_jwt_identity())
    it = IntentoQuiz(quiz_id=quiz_id, estudiante_id=user_id)
    db.session.add(it); db.session.commit()
    return {"intento_id": it.id}

@bp.post("/attempts/<int:intento_id>/submit")
@jwt_required()
def submit_attempt(intento_id):
    data = request.get_json() or {}
    respuestas = data.get("respuestas", {})
    total = 0; correctas = 0
    for pid, oid in respuestas.items():
        total += 1
        op = Opcion.query.get(oid)
        if op and op.correcta:
            correctas += 1
    puntaje = round((correctas/total)*100, 2) if total else 0.0
    intento = IntentoQuiz.query.get_or_404(intento_id)
    intento.puntaje = puntaje; intento.entregado = True
    db.session.commit()
    return {"puntaje": puntaje, "correctas": correctas, "total": total}
